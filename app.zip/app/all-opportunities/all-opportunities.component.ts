import { Component } from '@angular/core';

@Component({
    selector: 'all-opportunities',
    templateUrl: 'app/all-opportunities/all-opportunities.component.html',
    styleUrls: ['app/all-opportunities/all-opportunities.component.css']
})

export class AllOpportunities {
    picture_url: string = "http://wikitravel.org/upload/shared//5/5e/Panama_City_Banner.jpg"
}