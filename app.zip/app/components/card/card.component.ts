import { Component, Input } from '@angular/core';

@Component({
    selector: 'card',
    templateUrl: 'app/components/card/card.component.html',
    styleUrls: ['app/components/card/card.component.css']
})

export class Card {
    @Input() source: string

}