import { Component } from '@angular/core';

@Component({
    selector: 'header',
    templateUrl: 'app/components/header/header.component.html',
    styleUrls: ['app/components/header/header.component.css']
})

export class Header {}