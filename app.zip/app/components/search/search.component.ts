import { Component } from '@angular/core';

@Component({
    selector: 'search',
    templateUrl: 'app/components/search/search.component.html',
    styleUrls: ['app/components/search/search.component.css']
})

export class Search {}