"use strict";
var all_opportunities_component_1 = require('./all-opportunities/all-opportunities.component');
var profile_page_component_1 = require('./profile-page/profile-page.component');
var header_component_1 = require('./components/header/header.component');
var card_component_1 = require('./components/card/card.component');
var search_component_1 = require('./components/search/search.component');
exports.routes = [
    { path: '', component: all_opportunities_component_1.AllOpportunities },
    { path: 'profile', component: profile_page_component_1.ProfilePage }
];
exports.componentDeclarations = [
    all_opportunities_component_1.AllOpportunities,
    profile_page_component_1.ProfilePage,
    header_component_1.Header,
    card_component_1.Card,
    search_component_1.Search
];
//# sourceMappingURL=app.routing.js.map