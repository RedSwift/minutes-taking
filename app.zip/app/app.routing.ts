import { AllOpportunities } from './all-opportunities/all-opportunities.component';
import { ProfilePage } from './profile-page/profile-page.component';

import { Header } from './components/header/header.component';
import { Card } from './components/card/card.component';
import { Search } from './components/search/search.component';

export const routes = [
    { path: '', component: AllOpportunities },
    { path: 'profile', component: ProfilePage}
];

export const componentDeclarations = [
    AllOpportunities,
    ProfilePage,
    Header,
    Card,
    Search
];