import { Component } from '@angular/core';

@Component({
    selector: 'profile-page',
    templateUrl: 'app/profile-page/profile-page.component.html',
    styleUrls: ['app/profile-page/profile-page.component.css']
})

export class ProfilePage {}